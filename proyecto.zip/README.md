# Mundial 2026 · Hora española

App del calendario del Mundial 2026 (WebView) con:
- Actualización automática de resultados desde openfootball (+ botón Actualizar).
- Horarios en hora española peninsular.
- ⭐ Favoritos: cada usuario elige hasta 3 selecciones, cada una con su color.
- 📊 Grupos: clasificaciones de los 12 grupos calculadas solas.
- Fase final con fechas y cruces a la espera.

## Compilar el APK (sin instalar nada)
1. Sube todo este contenido a un repositorio de GitHub.
2. Ve a la pestaña **Actions** y espera a que el flujo **Build APK** termine en verde.
3. Entra en esa ejecución y descarga el artefacto **app-debug.apk**.

La app se firma siempre con la misma clave (carpeta `keystore/`), así que las
futuras versiones se instalan **encima** de la anterior sin desinstalar.

## Versión web (iOS / enlace)
El archivo `app/src/main/assets/index.html` es la app completa y autónoma.
Súbelo como `index.html` a GitHub Pages para tener un enlace que se abre en
Safari y se añade a la pantalla de inicio.
